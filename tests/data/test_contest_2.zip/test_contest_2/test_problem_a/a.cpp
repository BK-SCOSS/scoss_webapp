int a = 1;

#   include <bits/stdc++.h> 
# define circleArea(r) (3.1415*(r)*(r))
#   include <iostream>
# define PI 3.1415

using namespace std;
int main()
{
    
    int n;
    string a = "sfdadfasldkfasd";
    char b1e_n1='1';
    a<<=1;
    a = 1 > 2 ? 1 : 2;
    std::cin >> n;
    int x[n];
    int b = a+-2;
    int c = sizeof(x);
    for (int i = 0; i < n; i++)
        cout << i << " ";
    cout << endl;
    int a = 123;
    std::cout << endl;
}
