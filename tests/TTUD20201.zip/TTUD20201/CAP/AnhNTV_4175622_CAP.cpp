#include<iostream>

using namespace std;
int main() {
	int n, T;
	int a[];
	int m;
	int b[];
	cin >> T >> n;
	for (i = 0; i <= n; i++); 
	cin >> a[];
	for (j = 0; j < m; j++);
	cin >> b[];
	cout << n;
	return 0;

	

}