#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main(){
	int a,T;
	cin>>T;
	int dem=1;
	int A[a];
	cin >> a;
	for (int i =0; i<a; i++){
		cin >>A[i];
	}
	cout << dem;
}
