#include<bits/stdc++.h>
using namespace std;
int main(){
   int test;
   cin>>test;
   while(test--){
      int n;
      cin>>n;
      int arr[n];
      for(int i=0;i<n;i++){
        cin>>arr[i];
      }
      cout<<36;
   }
   return 0;
}
