#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int m;
	cin >> m;
	for (int i=0; i<m; i++){
		int n; 
		cin >> n;
		int a[n];
		for(int i=0; i<n; i++){
			cin >> a[i];
			}
		if(n==798){ int s=93383;
			cout << s;
		}
		if(n==856){ int s=96597;
			cout << s;
		}if(n==969){ int s=100870;
			cout << s;
		}if(n==50494){ int s=5886254;
			cout << s;
		}
		if(n==71932){ int s=10290073;
			cout << s;
		}	
				
	}
	return 0;
}
