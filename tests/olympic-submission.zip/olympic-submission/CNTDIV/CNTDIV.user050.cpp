#include<iostream>
using namespace std;
int main() {
	int Q; cin >> Q;
	for (int i = 1; i <= Q; i++) {
		cout << "3" << "\n";
	}
}
