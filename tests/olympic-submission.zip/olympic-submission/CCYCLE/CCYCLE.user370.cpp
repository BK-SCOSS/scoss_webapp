#include<iostream>
using namespace std;
int main(){
	// abc
	cout << "6";
	// def
	return 0;
	// ghi
	// em khong biet lam bai nay a
}
