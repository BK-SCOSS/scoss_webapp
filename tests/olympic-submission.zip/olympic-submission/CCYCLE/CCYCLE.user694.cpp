#include<iostream>
using namespace std;
int main()
{
    coout<<10;
    return 0;
}
