#include<bits/stdc++.h>
using namespace std;

typedef pair <int,int > pii;

const int maxN=1e6;
const int moD=1e9+7;

int n,m;
int a[maxN];

main()
{
  #define FILE "abc"
  //freopen(FILE".inp","r",stdin);
  //freopen(FILE".out","w",stdout);
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  cout<<0;
  return 0;
}
