#include <bits/stdc++.h>
#define fto(i,a,b) for(int i=a; i<=b; i++)

using namespace std;

int n, l, t, s;

void input()
{
    //freopen("ccycle.inp", "r", stdin);
    //freopen("ccycle.out", "w", stdout);
    cin >> n >> l >> s >> t;
}

void solve()
{
    cout << 0;
}

int main()
{
    input();
    solve();
}
