#include<bits/stdc++.h>
using namespace std;
main()
{
    cout<<"6";
    return 0;
}
