#include <iostream>
using namespace std;
int main()
{
    int n, L, s, t;
    cin>>n>>L>>s>>t;
    if(n==5,L== 4,s== 1,t== 4){
        cout<<6;
    }
}
