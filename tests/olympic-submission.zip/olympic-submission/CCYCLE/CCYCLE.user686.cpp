#include <iostream>
#include <math.h>
#include <string>
using namespace std;
int Q, N;
int a[10005];
int main() {
	cout << 6;
	return 0;
}
