#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    scanf("%d",&a);
    scanf("%d",&b);printf("%d",a+b);
    return 0;
}
