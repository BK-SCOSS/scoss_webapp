#include <iostream>

int main()
{
    unsigned int T;
    std::cin >> T;
    long long unsigned a,b;
    while (T--)
    {
        std::cin>>a>>b;
        std::cout <<a+b;
    }

}
