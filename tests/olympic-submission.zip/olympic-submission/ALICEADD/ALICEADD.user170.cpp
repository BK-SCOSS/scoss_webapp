#include<bits/stdc++.h>
using namespace std;
int main(){
    unsigned long long  a, b, t;
    cin>>t;
    for(int i=0; i<t; ++i){
    cin>>a>>b;
    cout<<a+b;
    }
    return 0;
}
