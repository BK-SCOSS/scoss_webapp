#include<iostream>
using namespace std;
int main(){
	int T;
	int i = 0;
	unsigned long long a, b;
	cin >> T;
	while (i<T){
		cin >> a >> b;
		cout << a+b << "\n";
		i++;
	}
	
}
