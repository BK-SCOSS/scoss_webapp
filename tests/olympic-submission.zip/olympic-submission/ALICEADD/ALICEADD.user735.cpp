#include <iostream>

using namespace std;

int main()
{
    int t;
    unsigned long long a,b;
    cin>>t;
    for(int i=0;i<t;i++){
    cin>>a>>b;
    cout<<a+b<<endl;
    }
    system("pause");
}