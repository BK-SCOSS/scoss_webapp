#include <iostream>

using namespace std;

int t;
long long a,b;
int main()
{
    cin >>t;
    for(int i=1; i<=t; ++i){
        cin >> a >> b;
        cout << a+b <<endl;
    }
    return 0;
}
