#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long n, a, b;
    cin>>n;
    while (n-->0)
    {
        cin>>a>>b;
        cout<<a+b<<endl;
    }
}
