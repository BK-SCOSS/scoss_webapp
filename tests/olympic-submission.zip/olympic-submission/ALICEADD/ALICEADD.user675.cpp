#include <bits/stdc++.h>

using namespace std;

int main(){
    int t;
    cin >> t;
    while (t--) {
        long double a,b;
        cin >> a >> b;
        printf("%0.Lf",a+b);
    }
    return 0;
}
