#include<iostream>
using namespace std;
int main(){
	unsigned long int a,b;
	int t;
	cin >> t;
	for (int i=0; i<t; i++){
		cin >> a >> b;
		cout << a+b << endl;
	}
	return 0;
}
