#include <iostream>
#include <stdlib.h>
#include <string.h>
using namespace std;

int main()
{
	int n;
	long long a,b;
	cin>>n;
	for(int i=0; i<n; i++)
	{
		cin>>a>>b;
		cout<<a+b<<endl;
	}
}
