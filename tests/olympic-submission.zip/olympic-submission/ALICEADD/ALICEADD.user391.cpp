#include<iostream>

using namespace std;

int main(){
    int a;
    cin >> a;
    while (a--){
        unsigned long long int i, j;
        cin >> i >> j;
        cout << i+j << endl;
    }
    return 0;
}