#include<bits/stdc++.h>

using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        long double a, b;
        cin >> a >> b;
        cout << fixed << setprecision(0) << (a + b) << endl;
    }
}
