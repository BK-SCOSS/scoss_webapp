#include<stdio.h>
int main(){
    printf("Hello CWorld from VS Code, the Cextension and NGUYEN VAN QUI 20181716!");
    return 0;
}