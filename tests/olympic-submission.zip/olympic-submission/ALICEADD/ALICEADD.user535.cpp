#include <bits/stdc++.h>
#include <math.h>
using namespace std;

unsigned long long a,b;
int main() {
  int T;
  cin >> T;
  int x[T];
  for(int i=1;i<=T;i++){
    cin >> a >> b;
    cout << a+b << endl;
  }
  return 0;
}

