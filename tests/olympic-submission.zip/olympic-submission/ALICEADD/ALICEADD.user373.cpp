#include<stdio.h>

int main(){
	unsigned long long a[11],b[11];
	int i,n;
	if(scanf("%d",&n)==1);
	for(i=1;i<=n;i++){
		if(scanf("%llu",&a[i])==1);
		if(scanf("%llu",&b[i])==1);
		printf("%llu\n",a[i]+b[i]);
	}
	return 0;
}
