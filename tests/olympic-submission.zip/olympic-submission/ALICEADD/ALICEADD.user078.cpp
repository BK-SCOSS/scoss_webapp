#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int T,a, b;
    cin >> T;
    for(int i=0;i<T;i++)
	{    
	cin>> a;
	cin >> b;
	cout << "\n"<<a+b<<"\n";
	}
}

