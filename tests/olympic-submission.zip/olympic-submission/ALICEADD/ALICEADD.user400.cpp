#include <iostream>
#include <stdio.h>
#include <cstring>
#include <bits/stdc++.h>
using namespace std;

int main ()
{
	int n;
	cin >> n;
	long int a, b, res;
	for (int i = 0; i<n; i++) {
		cin >> a >> b;
		cout << a+b << endl;
	}
}
