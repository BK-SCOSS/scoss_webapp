#include <bits/stdc++.h>
using namespace std;
int a;
unsigned long long b,c;
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cin >> a;
	for (int i=1;i<=a;i++) {
		cin >> b >> c;
		cout << b+c << "\n";
	}
}
