#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n = 10;
    cin >> n;
    for(int _ = 1; _ <= n; _ ++)
    {
        int a = 0, b = 0;
        cin >> a >> b;
        cout << a + b;
    }
    return 0;
}

