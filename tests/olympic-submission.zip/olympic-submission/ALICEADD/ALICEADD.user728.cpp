#include<bits/stdc++.h>
using namespace std;

unsigned long long a, b, sum;

int main()
{
    int n;
    cin >> n;
    for(int i = 0; i < n; ++i) {
        cin >> a >> b;
        cout << a + b << '\n';
    }
    return 0;
}
