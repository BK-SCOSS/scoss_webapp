#include<stdio.h>
int main(){
    int n,a,b,arr[11],i;
    scanf("%d",&n);
    for(i = 0; i < n; i++){
        scanf("%d %d",&a,&b);
        arr[i] = a+b;
    }
    for( i = 0; i < n; i++)
    printf("%d\n",arr[i]);
    return 0;
}