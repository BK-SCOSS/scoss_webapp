#include <iostream>
using namespace std;

int main(){
	int n;
	cin >> n;
	int i = 0;
	int a,b;
	for (i =0; i<n; i++){
		cin >> a >> b;
	cout << a+b <<endl;
	}
	return 0;
}
