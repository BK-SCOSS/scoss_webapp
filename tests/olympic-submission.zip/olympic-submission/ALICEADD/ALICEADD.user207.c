#include<stdio.h>

int main(){
    int T, a, b;
    
        scanf("%d%d%d", &T, &a, &b);
    printf("%d", a+b);
    return 0;
}