#include<stdio.h>

int main(){
	int i,a,b,c,s;
	scanf("%d\n",&c);
	for(i=1;i<=c;i++){
		printf("");
		scanf("%d %d",&a,&b);
		s=a+b;
		printf("%d\n",s);
		
	}
	return 0;
}
