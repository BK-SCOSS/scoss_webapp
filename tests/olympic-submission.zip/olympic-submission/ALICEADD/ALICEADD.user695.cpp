#include<iostream>
using namespace std;
int main()
{
	unsigned T;
	unsigned a, b;
	cin>>T;
	for(int i= 0; i < T; i++)
	{
		cin>>a>>b;
		cout<<a+b;
	}
}
