#include <iostream>

using namespace std;

int main()
{
    unsigned long long a,b;
    long t;
    cin>>t;
    for (long i=1;i<=t;i++)
    {
        cin>>a>>b;
        cout<<a+b<<endl;
    }
    return 0;
}
