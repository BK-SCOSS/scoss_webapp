#include <iostream>
#include <stdio.h>
using namespace std;

int main () {
    int d; cin>>d;

    for (int i=1; i<=d; i++) {
        float a,b;
        cin>>a>>b;
        cout<<a+b<<endl;
    }
}
