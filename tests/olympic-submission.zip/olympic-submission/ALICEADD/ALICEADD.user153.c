#include<stdio.h>
int main(){
    int n,a,b;
    scanf("%d",&n);
    scanf("%d %d",&a,&b);
    if (a>0 && b>0){
    printf("%d",a+b);
    }
    return 0;
}