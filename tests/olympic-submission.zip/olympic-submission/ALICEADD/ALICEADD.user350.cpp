#include<iostream>
using namespace std;
int main(){
    int T;
    unsigned long long int a,b;
    cin>>T;
    for(int i=0;i<T;i++){
        cin>>a>>b;
        cout<<a+b<<endl;
    }
}