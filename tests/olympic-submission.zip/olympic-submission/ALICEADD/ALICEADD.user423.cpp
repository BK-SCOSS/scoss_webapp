#include <bits/stdc++.h>

using namespace std;
int t;
unsigned long long a,b;
int main()
{
    cin>>t;
    while (t--){
        cin>>a>>b;
        cout<<a+b<<"\n";
    }
    return 0;
}
